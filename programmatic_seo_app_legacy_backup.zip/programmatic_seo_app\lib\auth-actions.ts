"use server";

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'stoic_admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'St0!cH3@lth#2024$Adm!n';

export async function loginAdmin(prevState: any, formData: FormData) {
  const username = formData.get('username') as string;
  const password = formData.get('password') as string;

  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    // Set a secure cookie for the session
    const expires = new Date();
    expires.setDate(expires.getDate() + 7); // 7 days expiration

    cookies().set('admin_session', 'authenticated_admin_user_v1', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      expires,
      path: '/'
    });

    return { success: true, redirect: '/admin' };
  }

  return { success: false, message: 'Invalid username or password.' };
}

export async function logoutAdmin() {
  cookies().delete('admin_session');
  redirect('/admin/login');
}
