import { supabase } from '../../../lib/supabaseClient'
import { notFound } from 'next/navigation'
import EntityGraph from '../../../components/EntityGraph'

// ==============================================================================
// NEXT.JS PROGRAMMATIC SEO (DYNAMIC ROUTING + ISR)
// This single file handles millions of URLs without writing them manually.
// E.g., /jobs/software-engineer-in-mumbai
// ==============================================================================

// 1. DYNAMIC METADATA GENERATION (Next.js 13+ App Router standard)
export async function generateMetadata({ params }) {
  const { category, slug } = params

  // Fetch only the SEO titles from Database for extreme speed
  const { data: pageData } = await supabase
    .from('programmatic_pages')
    .select('seo_title, meta_description')
    .eq('slug', slug)
    .single()

  if (!pageData) {
    return { title: 'Not Found' }
  }

  return {
    title: pageData.seo_title,
    description: pageData.meta_description,
    openGraph: {
      title: pageData.seo_title,
      description: pageData.meta_description,
      type: 'article',
    }
  }
}

// 2. PAGE RENDERER (Vercel ISR Logic)
export default async function ProgrammaticPage({ params }) {
  const { category, slug } = params

  // Fetch the full content for the page
  const { data: pageData, error } = await supabase
    .from('programmatic_pages')
    .select('*')
    .eq('slug', slug)
    .single()

  if (error || !pageData) {
    // Elegant fallback if the database row doesn't exist during ISR
    notFound()
  }

  // Extract Wikidata links if available in schema_markup
  let wikidataLinks = [];
  if (pageData.schema_markup && Array.isArray(pageData.schema_markup)) {
    wikidataLinks = pageData.schema_markup;
  } else if (pageData.schema_markup && pageData.schema_markup.sameAs) {
    wikidataLinks = pageData.schema_markup.sameAs;
  }

  // Define generic company and author data (you can later move this to a DB or config)
  const companyData = {
    name: "My Programmatic SEO Company",
    linkedinUrl: "https://linkedin.com/company/mycompany",
    twitterUrl: "https://twitter.com/mycompany"
  };
  
  const authorData = {
    name: "Admin User",
    slug: "admin-user",
    title: "Senior Content Editor"
  };

  const articleData = {
    title: pageData.seo_title,
    description: pageData.meta_description,
    slug: slug
  };

  return (
    <main className="container mx-auto p-8">
      {/* Advanced Knowledge Graph Injection */}
      <EntityGraph 
        articleData={articleData}
        authorData={authorData}
        companyData={companyData}
        wikidataLinks={wikidataLinks}
      />
      
      {/* Dynamic Content Rendering */}
      <article className="prose lg:prose-xl">
        <h1>{pageData.h1_tag}</h1>
        
        {/* We use dangerouslySetInnerHTML to render HTML content from Supabase */}
        <div dangerouslySetInnerHTML={{ __html: pageData.html_content }} />
        
        <div className="mt-8 p-4 bg-gray-100 rounded-lg">
          <h3>Local Data / Statistics</h3>
          <p>This section is automatically populated by our Python Data Ingestion pipeline!</p>
        </div>
      </article>
    </main>
  )
}

// 3. ISR CONFIGURATION (The Secret to Vercel's Speed)
// This tells Vercel: Cache this page, but if someone visits it after 3600 seconds (1 hour),
// fetch fresh data from Supabase in the background and update the cache.
export const revalidate = 3600 
